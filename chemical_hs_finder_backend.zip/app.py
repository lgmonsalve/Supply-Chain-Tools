from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/")
def home():
    return "Chemical HS Code Finder Backend Running!"

@app.route("/predict-hs", methods=["POST"])
def predict_hs():
    if 'image' not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    image = request.files['image']
    filename = secure_filename(image.filename)
    image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    image.save(image_path)

    # TODO: Add real chemical structure recognition here
    # For now, we'll simulate a prediction
    dummy_hs_code = "2909.19"  # Example for ethers

    return jsonify({
        "hs_code": dummy_hs_code,
        "description": "Simulated HS code for a chemical compound"
    })

if __name__ == "__main__":
    app.run(debug=True)